## Task_3:  Play an Ansible Role from your VM (workstation) to an EC2 (Apache Web Server)
This is the improvment Task_2 that we will deploy the play on the ec2

### Ensure security allowance
Launch an ec2 from the AWS management console then in its security group:  
- Add the inbound rule of ssh from the current vm instance that you will run or upload the playbook from.
- Add the custom TCP port 88.  

---

### Modify the inventory
Add the ec2 Public IP of the ec2 instance in the inventory along with the key-pair assigned to it as the following  
`3.149.252.117 ansible_user=ec2-user ansible_ssh_private_key_file=/home/student/mainkp.pem`  

Note that after uploading your key to the current VM you have to change the permission to 400 as when you use an EC2 key-pair (typically a .pem file) to connect via SSH, the permissions must be restricted so that only the file's owner can read it — otherwise, SSH will refuse to use it for security reasons.  

###
